package com.marolix.Bricks99.utility;

public class RegExCheck {

	public static void main(String[] args) {
		String p="([A-Za-z0-9,-\s]+)";
		System.out.println(" ".matches(p));
	}

}
