package com.marolix.Bricks99.service;

public interface EmailSender {
    public void sendEmail(String to, String subject, String body) ;
}
